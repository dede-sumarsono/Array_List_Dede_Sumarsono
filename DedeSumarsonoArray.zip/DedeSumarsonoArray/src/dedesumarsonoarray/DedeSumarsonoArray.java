/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dedesumarsonoarray;

/**
 *
 * @author DD
 */
public class DedeSumarsonoArray {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String [] ortu = {"Anis Sariwati", "Heri Hartono"};
        String [] anak = {"Kiki Mardianto","Dede Sumarsono"};
        String [] nenek = {"Nisvara", "Soeradi"};
        String [][] saudara_jauh = {
            {"Elisa","0852-3993-1234"},
            {"Luki","0852-3321-1233"},
            {"Imel","0823-4452-1209"},
            {"Dedy","0823-9091-2123"},
            {"Itok","0852-3221-9488"}};
        int jumkel = ortu.length+anak.length+nenek.length+saudara_jauh.length;
        
        System.out.println("Namaku Adalah "+anak[1]);
        System.out.println("Saya "+anak.length+" Bersaudara");
        
        System.out.println("");
        for (int i = 0;i<anak.length;i++){
            if (anak[i]=="Dede Sumarsono"){
                System.out.println("Saya adalah anak ke-"+(i+1));
            }
        }
        
        System.out.println("");
        System.out.println("Nama Orang Tua Saya Adalah : ");
        for (int i=0;i<ortu.length;i++){
            System.out.println(ortu[i]);
            }
        
        System.out.println("");
        System.out.println("Anak-Anaknya Bernama :");
        for (int i = 0; i<anak.length;i++){
            System.out.println(anak[i]);
            }
        
        System.out.println("");
        System.out.println("Saudara Jauh Saya Adalah :");
        for (int i=0;i<saudara_jauh.length;i++){
            System.out.print(saudara_jauh[i][0]);
            System.out.println("   No Teleponnya : "+saudara_jauh[i][1]);
            
        }
        
        System.out.println("");
        System.out.println("Nenek dan Kakek Saya Bernama :");
        
        System.out.println("");
        System.out.println("Jadi Jumlah Anggota Keluarga Saya Adalah "+jumkel);
        
        System.out.println("");
    }
    
}
